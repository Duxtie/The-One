from datetime import datetime


# For the raw events given (a List of Dictionaries) returns normalized log events as a List of
# Dictionaries having the following keys: 'server', 'date', 'severity', 'process', 'message'.
def transmogrify(raw_events: [dict]) -> [dict]:
    # Write your solution here and in any helper functions you wish to create.
    # Do not change this function signature or this could break tests.

    date_format = '%Y-%m-%dT%H:%M:%S.%f'

    actual_event = []
    for event in raw_events:

        # set date format
        if "date" in event:
            if isinstance(event['date'], int):
                try:
                    event['date'] = datetime.utcfromtimestamp(event['date']).strftime(date_format)
                except:
                    event['date'] = datetime.fromtimestamp(event['date'] / 1e3).strftime(date_format)
            else:
                event['date'] = datetime.strptime(event['date'], date_format).strftime(date_format)

        actual_event.append(event)

    return actual_event

    # raise NotImplementedError
